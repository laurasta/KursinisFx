package com.example.kursinisfx.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor

public class Forum {
    private String title;
    private String description;

    public Forum(String title, String description) {
        this.title = title;
        this.description = description;
    }
}