package com.example.kursinisfx.model;

import lombok.*;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Entity
public class Trucker extends User implements Serializable{
    private String healthCertificate;
    private String driverLicense;
    @OneToMany(mappedBy = "driver", cascade = CascadeType.ALL)
    private List<Destination> myDestinations;

    public Trucker(String login, String password, String name, String surname, String email, String phoneNumber, String healthCertificate, String driverLicense) {
        super(login, password, name, surname, email, phoneNumber);
        this.healthCertificate = healthCertificate;
        this.driverLicense = driverLicense;
    }
}
