package com.example.kursinisfx;

import com.example.kursinisfx.model.TruckerSystem;
//import com.example.kursinisfx.utils.MenuUtil;
import com.example.kursinisfx.utils.RW;

import java.util.Scanner;

//public class Start {
//    public static void main(String[] args) {
//
//        //Skaitoma is failo, tikrinama ar tuscias, jei ne tai vykdysiu
//
//
//        TruckerSystem truckerSystem = RW.readFromFile();
//        if(truckerSystem == null) truckerSystem = new TruckerSystem();
//
//        Scanner scanner = new Scanner(System.in);
//        String cmd = "";
//
//        while(!cmd.equals("q")) {
//            System.out.println("""
//                    Please choose an option:
//                    u - manage users.\s
//                    d - manage destinations.\s
//                    c - manage cargo.\s
//                    s - save to file.\s
//                    q - quit system.\s
//                    """);
//
//            cmd = scanner.nextLine();
//
//            switch (cmd) {
//                case "u":
//                    //manage users
//                    MenuUtil.controlUsers(scanner, truckerSystem);
//                    break;
//                case "d":
//                    //manage destinations
//                    MenuUtil.controlDestinations(scanner, truckerSystem);
//                    break;
//                case "c":
//                    //manage cargos
//                    MenuUtil.controlCargos(scanner, truckerSystem);
//                    break;
//                case "s":
//                    //save data
//                    RW.writeToFile(truckerSystem);
//                    System.out.println("Data saved!\n");
//                    break;
//                case "q":
//                    RW.writeToFile(truckerSystem);
//                    System.out.println("Data saved!\n");
//                    System.out.println("Bye!\n");
//                    break;
//                default:
//                    System.out.println("Try again!\n");
//                    break;
//            }
//        }
//    }
//}
