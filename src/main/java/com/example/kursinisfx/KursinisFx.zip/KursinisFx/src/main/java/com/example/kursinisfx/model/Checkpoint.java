package com.example.kursinisfx.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Checkpoint {
    private String title;
    private String checkpointAddress;
    private Boolean isReached;

    public Checkpoint(String checkpointAddress, Boolean isReached, String title) {
        this.checkpointAddress = checkpointAddress;
        this.isReached = isReached;
        this.title = title;
    }
}

