package com.example.kursinisfx.model;

public enum DestStatus {
    NEW, CANCELED, COMPLETED, IN_PROGRESS
}
