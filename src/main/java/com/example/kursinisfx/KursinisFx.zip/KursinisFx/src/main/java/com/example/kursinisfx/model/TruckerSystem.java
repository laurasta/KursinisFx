package com.example.kursinisfx.model;

import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;

@Data
public class TruckerSystem implements Serializable {
    private ArrayList<User> allUsers;
    private ArrayList<Destination> allDestinations;
    private ArrayList<Cargo> allCargos;

    public TruckerSystem() {
        this.allUsers = new ArrayList<>();
        this.allDestinations = new ArrayList<>();
        this.allCargos = new ArrayList<>();
    }
}
