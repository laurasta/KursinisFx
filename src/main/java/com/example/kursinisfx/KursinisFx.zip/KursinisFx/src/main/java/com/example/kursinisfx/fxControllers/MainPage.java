package com.example.kursinisfx.fxControllers;

public class MainPage {
}
