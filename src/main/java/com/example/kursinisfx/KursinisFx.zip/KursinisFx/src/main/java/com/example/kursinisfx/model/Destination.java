package com.example.kursinisfx.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Destination implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String routeStartAddress;
    private String destinationAddress;
    private DestStatus status;
    private String responsiblePerson;
    private LocalDateTime arrivalDate;
    private LocalDateTime departureDate;

    @ManyToOne
    private Trucker driver;

    public Destination(String routeStartAddress, String destinationAddress, DestStatus status, String responsiblePerson, LocalDateTime arrivalDate, LocalDateTime departureDate) {
        this.routeStartAddress = routeStartAddress;
        this.destinationAddress = destinationAddress;
        this.status = status;
        this.responsiblePerson = responsiblePerson;
        this.arrivalDate = arrivalDate;
        this.departureDate = departureDate;
    }
}
