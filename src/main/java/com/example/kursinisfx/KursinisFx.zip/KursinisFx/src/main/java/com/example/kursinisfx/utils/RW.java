package com.example.kursinisfx.utils;


import com.example.kursinisfx.model.TruckerSystem;

import java.io.*;

public class RW {
    public static void writeToFile(TruckerSystem truckerSystem){
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("database.txt")));
            out.writeObject(truckerSystem);
            out.close();
        } catch (IOException e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
        } finally {
            if(out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public static TruckerSystem readFromFile(){
        ObjectInputStream in = null;
        TruckerSystem truckerSystem = null;
        try {
            in = new ObjectInputStream(new BufferedInputStream(new FileInputStream("database.txt")));
            truckerSystem = (TruckerSystem) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (in != null){
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return truckerSystem;
    }
}
