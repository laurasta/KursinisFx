package com.example.kursinisfx.model;

import lombok.*;

import javax.persistence.Entity;
import java.io.Serializable;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Manager extends User implements Serializable {

    private String workEmail;
    private String tabNum;
    private Boolean isAdmin;

    public Manager(String login, String password, String name, String surname, String email, String phoneNumber, String workEmail, String tabNum, Boolean isAdmin) {
        super(login, password, name, surname, email, phoneNumber);
        this.workEmail = workEmail;
        this.tabNum = tabNum;
        this.isAdmin = isAdmin;
    }
}
