package com.example.kursinisfx.fxControllers;

public class LoginPage {
}
