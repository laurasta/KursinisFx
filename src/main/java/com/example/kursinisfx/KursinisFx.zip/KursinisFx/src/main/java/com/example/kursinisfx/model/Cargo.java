package com.example.kursinisfx.model;

import lombok.*;
import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Cargo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String type;
    private String weightKg;

    public Cargo(String type, String weightKg) {
        this.type = type;
        this.weightKg = weightKg;
    }
}