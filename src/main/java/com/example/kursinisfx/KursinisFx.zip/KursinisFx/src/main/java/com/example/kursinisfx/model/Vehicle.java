package com.example.kursinisfx.model;

import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Vehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String model;
    private Boolean outOfService;

    public Vehicle(String model, Boolean outOfService) {
        this.model = model;
        this.outOfService = outOfService;
    }
}
