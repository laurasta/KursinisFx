module com.example.kursinisfx {
    requires javafx.controls;
    requires javafx.fxml;
    requires lombok;
    requires java.persistence;
    requires mysql.connector.java;
    requires org.hibernate.orm.core;


    opens com.example.kursinisfx to javafx.fxml;
    exports com.example.kursinisfx;

}