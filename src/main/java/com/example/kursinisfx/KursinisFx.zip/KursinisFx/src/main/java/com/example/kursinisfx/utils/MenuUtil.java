//package com.example.kursinisfx.utils;
//
//import com.example.kursinisfx.model.*;
//
//import java.util.Scanner;
//
//public class MenuUtil {
//    public static void controlUsers(Scanner scanner, TruckerSystem truckerSystem) {
//        int cmd = 0;
//        while (cmd != 9) {
//            System.out.println("""
//                    Choose an option:
//                    1 - create
//                    2 - update
//                    3 - delete
//                    4 - view all
//                    5 - view by login
//                    9 - quit
//                    """);
//            cmd = scanner.nextInt();
//            scanner.nextLine();
//            if (cmd == 1) {
//                System.out.println("""
//                        Which type?
//                        t - Trucker
//                        m - Manager
//                        """);
//                String type = scanner.nextLine();
//                if (type.equals("t")) {
//                    System.out.println("""
//                            Enter information:
//                            login,
//                            password,
//                            name,
//                            surname,
//                            email,
//                            phoneNumber,
//                            healthCertificate,
//                            driverLicense.
//                            """);
//                    String[] info = scanner.nextLine().split(",");
//                    try {
//                        Trucker trucker = new Trucker(info[0].trim(), info[1].trim(), info[2].trim(), info[3].trim(), info[4].trim(), 1, info[5].trim(), null, null, true, info[6].trim(), info[7].trim());
//                        truckerSystem.getAllUsers().add(trucker);
//                    } catch (Exception e) {
//                        System.out.println("wrong input!\n");
//                    }
//
//                } else if (type.equals("m")) {
//                    System.out.println("""
//                            Enter information:
//                            login,
//                            password,
//                            name,
//                            surname,
//                            email,
//                            phoneNumber,
//                            workEmail.
//                            """);
//                    String[] info = scanner.nextLine().split(",");
//                    try {
//                        Manager manager = new Manager(info[0].trim(), info[1].trim(), info[2].trim(), info[3].trim(), info[4].trim(), 1, info[5].trim(), null, null, true, info[6].trim(), false);
//                        truckerSystem.getAllUsers().add(manager);
//                    } catch (Exception e) {
//                        System.out.println("wrong input!\n");
//                    }
//
//                }
//            } else if (cmd == 4) {
//                truckerSystem.getAllUsers().forEach(c -> System.out.println(c));
//            }
//        }
//
//    }
//
//    public static void controlDestinations(Scanner scanner, TruckerSystem truckerSystem) {
//        int cmd = 0;
//        while (cmd != 9) {
//            System.out.println("""
//                    Choose an option:
//                    1 - create
//                    2 - update
//                    3 - delete
//                    4 - view all
//                    5 - view by id
//                    9 - quit
//                    """);
//            cmd = scanner.nextInt();
//            scanner.nextLine();
//            if (cmd == 1) {
//                    System.out.println("""
//                            Enter information:
//                            routeStartAddress,
//                            destinationAddress,
//                            driver,
//                            responsiblePerson.
//                            """);
//                    String[] info = scanner.nextLine().split(",");
//                    try {
//                        Destination destination = new Destination("1", info[0].trim(), info[1].trim(), info[2].trim(), "new", info[3].trim(), null, null);
//                        truckerSystem.getAllDestinations().add(destination);
//                    } catch (Exception e) {
//                        System.out.println("wrong input!\n");
//                    }
//                } else if (cmd == 4) {
//                    truckerSystem.getAllDestinations().forEach(c -> System.out.println(c));
//                }
//            }
//    }
//    public static void controlCargos(Scanner scanner, TruckerSystem truckerSystem) {
//        int cmd = 0;
//        while (cmd != 9) {
//            System.out.println("""
//                    Choose an option:
//                    1 - create
//                    2 - update
//                    3 - delete
//                    4 - view all
//                    9 - quit
//                    """);
//            cmd = scanner.nextInt();
//            scanner.nextLine();
//            if (cmd == 1) {
//                    System.out.println("""
//                            Enter information:
//                            Type,
//                            weightKg.
//                            """);
//                    String[] info = scanner.nextLine().split(",");
//                    try {
//                        Cargo cargo = new Cargo(info[0].trim(), info[1].trim());
//                        truckerSystem.getAllCargos().add(cargo);
//                    } catch (Exception e) {
//                        System.out.println("wrong input!\n");
//                    }
//                } else if (cmd == 4) {
//                    truckerSystem.getAllCargos().forEach(c -> System.out.println(c));
//                }
//            }
//    }
//}
