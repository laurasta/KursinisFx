package com.example.kursinisfx.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Setter
@AllArgsConstructor
@NoArgsConstructor
@Getter
@ToString
@MappedSuperclass

public abstract class User implements Serializable {
    // kadangi abstract class User bus kai sablonas
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
    private String login;
    private String password;
    private String name;
    private String surname;
    private String email;
    private Integer id;
    private String phoneNumber;
    private LocalDate employmentDate;
    private LocalDate leaveDate;
    private Boolean isActive;

    public User(String login, String password, String name, String surname, String email, String phoneNumber) {
        this.login = login;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
}
