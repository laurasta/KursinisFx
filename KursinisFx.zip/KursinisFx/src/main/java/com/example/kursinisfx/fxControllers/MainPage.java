package com.example.kursinisfx.fxControllers;


import com.example.kursinisfx.HelloApplication;
import com.example.kursinisfx.hibernate.CommentHib;
import com.example.kursinisfx.hibernate.DestinationHib;
import com.example.kursinisfx.hibernate.ForumHib;
import com.example.kursinisfx.model.*;
import com.example.kursinisfx.hibernate.UserHib;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class MainPage implements Initializable {
    public ListView<Trucker> truckerList;
    public ListView<Manager> managerList;
    public TabPane allTabs;
    public Tab destTab;
    public ListView<Destination> destinationList;
    public TableView<TruckerTableParameters> TruckerTable;
    public TableColumn<TruckerTableParameters, String> colTruckerId;
    public TableColumn<TruckerTableParameters, String> colTruckerLogin;
    public TableColumn<TruckerTableParameters, String> colTruckerPsw;
    public TableColumn<TruckerTableParameters, String> colTruckerName;
    public TableColumn<TruckerTableParameters, String> colTruckerSurn;
    public TableColumn<TruckerTableParameters, String> colTruckerEmail;
    public TableColumn<TruckerTableParameters, String> colTruckerNumber;
    public TableColumn<TruckerTableParameters, String> colTruckerHealth;
    public TableColumn<TruckerTableParameters, String> colTruckerLicence;
    public MenuItem deleteItem;
    public MenuItem updateItem;
    public Tab forumTab;
    public ListView<Forum> forumList;
    public TreeView<Comment> commentTree;
    private ObservableList<TruckerTableParameters> data = FXCollections.observableArrayList();

    private EntityManagerFactory entityManagerFactory;
    private UserHib userHib;
    private CommentHib commentHib;
    private DestinationHib destinationHib;
    private ForumHib forumHib;
    private User user;

    public void setData(EntityManagerFactory entityManagerFactory, User user) {
        this.entityManagerFactory = entityManagerFactory;
        this.userHib = new UserHib(entityManagerFactory);
        this.destinationHib = new DestinationHib(entityManagerFactory);
        this.forumHib = new ForumHib(entityManagerFactory);
        this.user = user;
        fillAllLists();
        //disableData();
    }

    private void disableData() {

        if (user.getClass() == Trucker.class) {
            allTabs.getTabs().remove(destTab);
            //destinationTab.setDisable(true);
        }

    }

    private void fillAllLists() {
        List<Trucker> allTruckers = userHib.getAllTruckers();
        //allTruckers.forEach(c -> truckerList.getItems().add(c));

        for (Trucker c : allTruckers) {
            TruckerTableParameters truckerTableParameters = new TruckerTableParameters();
            truckerTableParameters.setTruckerId(String.valueOf(c.getId()));
            truckerTableParameters.setTruckerLogin(c.getLogin());
            truckerTableParameters.setTruckerPsw(c.getPassword());
            data.add(truckerTableParameters);
        }

        TruckerTable.setItems(data);

//        List<Destination> destinations = destinationHib.getAllDestinations();
//        destinations.forEach(d -> destinationList.getItems().add(d));
//
//        List<Forum> forums = forumHib.getAllForums();
//        forums.forEach(f -> forumList.getItems().add(f));
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void showDetails(ActionEvent event) {
    }

    public void deleteUser(ActionEvent event) {
    }

    public void updateUser() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("registration-page.fxml"));
        Parent parent = fxmlLoader.load();
//        RegistrationPage registrationPage = fxmlLoader.getController();
//        registrationPage.setData(entityManagerFactory, user, truckerList.getSelectionModel().getSelectedItem());
        Scene scene = new Scene(parent);
        Stage stage = new Stage();
        stage.initOwner(managerList.getScene().getWindow());
        stage.initModality(Modality.WINDOW_MODAL);
        stage.setTitle("Trucker system");
        stage.setScene(scene);
        stage.showAndWait();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        TruckerTable.setEditable(true);
        colTruckerId.setCellValueFactory(new PropertyValueFactory<>("truckerId"));
        colTruckerLogin.setCellValueFactory(new PropertyValueFactory<>("truckerLogin"));
        colTruckerLogin.setCellFactory(TextFieldTableCell.forTableColumn());
        colTruckerLogin.setOnEditCommit(t -> {
            t.getTableView().getItems().get(
                    t.getTablePosition().getRow()).setTruckerLogin(t.getNewValue());
            //Noriu kad eitu i db update
            Trucker trucker = userHib.getTruckerById(Integer.parseInt(t.getTableView().getItems().get(t.getTablePosition().getRow()).getTruckerId()));
            trucker.setLogin(t.getTableView().getItems().get(t.getTablePosition().getRow()).getTruckerLogin());
            userHib.updateUser(trucker);
        });

        colTruckerPsw.setCellValueFactory(new PropertyValueFactory<>("truckerPsw"));
    }

    public void showDestDetails(ActionEvent actionEvent) {
    }

    public void deleteDest(ActionEvent actionEvent) {
    }

    public void updateDest(ActionEvent actionEvent) {
    }

    public void loadComments() {
        List<Comment> comments = forumHib.getForumById(forumList.getSelectionModel().getSelectedItem().getId()).getComments();
        commentTree.setRoot(new TreeItem<>(new Comment()));
        commentTree.setShowRoot(false);
        commentTree.getRoot().setExpanded(true);
        comments.forEach(comment -> addTreeItem(comment, commentTree.getRoot()));
    }

    private void addTreeItem(Comment comment, TreeItem parent) {
        TreeItem<Comment> treeItem = new TreeItem<>(comment);
        parent.getChildren().add(treeItem);
        comment.getReplies().forEach(r -> addTreeItem(r, treeItem));
    }

    public void createComment() {
        commentHib = new CommentHib(entityManagerFactory);
        commentHib.createComment(new Comment("Title", "Text"));
    }

    public void deleteComment(ActionEvent actionEvent) {
    }

    public void updateComment(ActionEvent actionEvent) {
    }
}
