package com.example.kursinisfx.fxControllers;

import javafx.beans.property.SimpleStringProperty;

public class TruckerTableParameters {
    private SimpleStringProperty truckerId = new SimpleStringProperty();
    private SimpleStringProperty truckerLogin = new SimpleStringProperty();
    private SimpleStringProperty truckerPsw = new SimpleStringProperty();
    private SimpleStringProperty truckerName = new SimpleStringProperty();
    private SimpleStringProperty truckerSurn = new SimpleStringProperty();
    private SimpleStringProperty truckerEmail = new SimpleStringProperty();
    private SimpleStringProperty truckerNumber = new SimpleStringProperty();
    private SimpleStringProperty truckerHealth = new SimpleStringProperty();
    private SimpleStringProperty truckerLicence = new SimpleStringProperty();

    public TruckerTableParameters() {
    }

    public TruckerTableParameters(SimpleStringProperty truckerId, SimpleStringProperty truckerLogin, SimpleStringProperty truckerPsw, SimpleStringProperty truckerName, SimpleStringProperty truckerSurn, SimpleStringProperty truckerEmail, SimpleStringProperty truckerNumber, SimpleStringProperty truckerHealth, SimpleStringProperty truckerLicence) {
        this.truckerId = truckerId;
        this.truckerLogin = truckerLogin;
        this.truckerPsw = truckerPsw;
        this.truckerName = truckerName;
        this.truckerSurn = truckerSurn;
        this.truckerEmail = truckerEmail;
        this.truckerNumber = truckerNumber;
        this.truckerHealth = truckerHealth;
        this.truckerLicence = truckerLicence;
    }

    public String getTruckerId() {
        return truckerId.get();
    }

    public SimpleStringProperty truckerIdProperty() {
        return truckerId;
    }

    public void setTruckerId(String truckerId) {
        this.truckerId.set(truckerId);
    }

    public String getTruckerLogin() {
        return truckerLogin.get();
    }

    public SimpleStringProperty truckerLoginProperty() {
        return truckerLogin;
    }

    public void setTruckerLogin(String truckerLogin) {
        this.truckerLogin.set(truckerLogin);
    }

    public String getTruckerPsw() {
        return truckerPsw.get();
    }

    public SimpleStringProperty truckerPswProperty() {
        return truckerPsw;
    }

    public void setTruckerPsw(String truckerPsw) {
        this.truckerPsw.set(truckerPsw);
    }

    public String getTruckerName() {
        return truckerName.get();
    }

    public SimpleStringProperty truckerNameProperty() {
        return truckerName;
    }

    public void setTruckerName(String truckerName) {
        this.truckerName.set(truckerName);
    }

    public String getTruckerSurn() {
        return truckerSurn.get();
    }

    public SimpleStringProperty truckerSurnProperty() {
        return truckerSurn;
    }

    public void setTruckerSurn(String truckerSurn) {
        this.truckerSurn.set(truckerSurn);
    }

    public String getTruckerEmail() {
        return truckerEmail.get();
    }

    public SimpleStringProperty truckerEmailProperty() {
        return truckerEmail;
    }

    public void setTruckerEmail(String truckerEmail) {
        this.truckerEmail.set(truckerEmail);
    }

    public String getTruckerNumber() {
        return truckerNumber.get();
    }

    public SimpleStringProperty truckerNumberProperty() {
        return truckerNumber;
    }

    public void setTruckerNumber(String truckerNumber) {
        this.truckerNumber.set(truckerNumber);
    }

    public String getTruckerHealth() {
        return truckerHealth.get();
    }

    public SimpleStringProperty truckerHealthProperty() {
        return truckerHealth;
    }

    public void setTruckerHealth(String truckerHealth) {
        this.truckerHealth.set(truckerHealth);
    }

    public String getTruckerLicence() {
        return truckerLicence.get();
    }

    public SimpleStringProperty truckerLicenceProperty() {
        return truckerLicence;
    }

    public void setTruckerLicence(String truckerLicence) {
        this.truckerLicence.set(truckerLicence);
    }
}
