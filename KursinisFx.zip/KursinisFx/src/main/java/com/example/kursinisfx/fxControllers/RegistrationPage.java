package com.example.kursinisfx.fxControllers;

import com.example.kursinisfx.HelloApplication;
import com.example.kursinisfx.hibernate.UserHib;
import com.example.kursinisfx.model.Manager;
import com.example.kursinisfx.model.Trucker;
import com.example.kursinisfx.model.User;
import com.example.kursinisfx.model.UserType;
import com.example.kursinisfx.utils.FxUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class RegistrationPage implements Initializable {
    @FXML
    public TextField loginField;
    @FXML
    public PasswordField passwordField;
    @FXML
    public TextField nameField;
    @FXML
    public TextField surnameField;
    @FXML
    public TextField emailField;
    @FXML
    public TextField phoneNumberField;
    @FXML
    public CheckBox HealthCertifField;
    @FXML
    public Button createBtn;
    @FXML
    public TextField driverLicenseField;
    @FXML
    public RadioButton driverRadio;
    @FXML
    public RadioButton managerRadio;
    @FXML
    public TextField workEmailField;
    @FXML
    public TextField tabNumberField;
    @FXML
    public CheckBox isAdminField;
    @FXML
    public MenuItem cancelRegistration;
    @FXML
    public Label driverLicenseT;
    @FXML
    public Label workEmailT;
    private EntityManagerFactory entityManagerFactory;
    private User user;
    private UserHib userHib;
    private User selectedUser;

    final ToggleGroup group = new ToggleGroup();

    public void setData(EntityManagerFactory entityManagerFactory, User user, User selectedUser) {
        this.user = user;
        this.entityManagerFactory = entityManagerFactory;
        this.selectedUser = selectedUser;
        this.userHib = new UserHib(entityManagerFactory);
        fillFields();
    }

    private void fillFields() {
        loginField.setText(selectedUser.getLogin());
        passwordField.setText(selectedUser.getPassword());
        nameField.setText(selectedUser.getName());
        surnameField.setText(selectedUser.getSurname());
        emailField.setText(selectedUser.getEmail());
        phoneNumberField.setText(selectedUser.getPhoneNumber());
        Trucker selectedTrucker = userHib.getTruckerById(selectedUser.getId());
        Manager selectedManager = userHib.getManagerById(selectedUser.getId());
        if(selectedUser.getUserType() == UserType.TRUCKER){
            driverLicenseField.setText(selectedTrucker.getDriverLicense());
            HealthCertifField.setSelected(selectedTrucker.getHealthCertificate());
            workEmailField.setVisible(false);
            isAdminField.setVisible(false);
            workEmailT.setVisible(false);
            managerRadio.setVisible(false);
            driverRadio.setSelected(true);
            disableFields();
        } else if(selectedUser.getUserType() == UserType.MANAGER){
            workEmailField.setText(selectedManager.getWorkEmail());
            isAdminField.setSelected(selectedManager.getIsAdmin());
            driverLicenseField.setVisible(false);
            driverLicenseT.setVisible(false);
            HealthCertifField.setVisible(false);
            driverRadio.setVisible(false);
            managerRadio.setSelected(true);
            disableFields();
        }
        createBtn.setOnAction(actionEvent ->  {
            try {
                updateUser();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        createBtn.setText("Update");
    }

    public void updateUser() throws IOException {
        Trucker selectedTrucker = userHib.getTruckerById(selectedUser.getId());
        Manager selectedManager = userHib.getManagerById(selectedUser.getId());
        if(selectedUser.getUserType() == UserType.TRUCKER){
            selectedTrucker.setLogin(loginField.getText());
            selectedTrucker.setPassword(passwordField.getText());
            selectedTrucker.setName(nameField.getText());
            selectedTrucker.setSurname(surnameField.getText());
            selectedTrucker.setEmail(emailField.getText());
            selectedTrucker.setPhoneNumber(phoneNumberField.getText());
            selectedTrucker.setDriverLicense(driverLicenseField.getText());
            selectedTrucker.setHealthCertificate(Boolean.valueOf(HealthCertifField.getText()));
            userHib.editUser(selectedTrucker);
        } else if(selectedUser.getUserType() == UserType.MANAGER){
            selectedManager.setLogin(loginField.getText());
            selectedManager.setPassword(passwordField.getText());
            selectedManager.setName(nameField.getText());
            selectedManager.setSurname(surnameField.getText());
            selectedManager.setEmail(emailField.getText());
            selectedManager.setPhoneNumber(phoneNumberField.getText());
            selectedManager.setWorkEmail(workEmailField.getText());
            selectedManager.setIsAdmin(Boolean.valueOf(isAdminField.getText()));
            userHib.editUser(selectedManager);
        }
        FxUtils.generateAlert(Alert.AlertType.INFORMATION, "User update report", "User updated successfully!");
        allUsers();
    }

    public void setData(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
        this.userHib = new UserHib(entityManagerFactory);
    }

    public void disableFields() {
        driverRadio.setToggleGroup(group);
        managerRadio.setToggleGroup(group);

        if (driverRadio.isSelected()) {
            workEmailField.setDisable(true);
            isAdminField.setDisable(true);
            HealthCertifField.setDisable(false);
            driverLicenseField.setDisable(false);
        } else if (managerRadio.isSelected()) {
            HealthCertifField.setDisable(true);
            driverLicenseField.setDisable(true);
            workEmailField.setDisable(false);
            isAdminField.setDisable(false);
        } else {
            workEmailField.setDisable(true);
            isAdminField.setDisable(true);
            HealthCertifField.setDisable(true);
            driverLicenseField.setDisable(true);
        }
    }

    public void createNewUser() throws IOException {
        if (driverRadio.isSelected()) {
            Trucker trucker = new Trucker(loginField.getText(), passwordField.getText(), nameField.getText(), surnameField.getText(), emailField.getText(), phoneNumberField.getText(), HealthCertifField.isSelected(), driverLicenseField.getText());
            userHib.createUser(trucker);
        } else {
            Manager manager = new Manager(loginField.getText(), passwordField.getText(), nameField.getText(), surnameField.getText(), emailField.getText(), phoneNumberField.getText(),  workEmailField.getText(), isAdminField.isSelected());
            userHib.createUser(manager);
        }
        FxUtils.generateAlert(Alert.AlertType.INFORMATION, "User registration report", "User created successfully!");

        returnToPrevious();
    }

    private void returnToPrevious() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("login-page.fxml"));

        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) loginField.getScene().getWindow();
        stage.setTitle("Trucker system");
        stage.setScene(scene);
        stage.show();
    }

    public void allUsers() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("all-users-window.fxml"));
        Parent root = fxmlLoader.load();

        AllUsersWindow allUsersWindow = fxmlLoader.getController();
        allUsersWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) loginField.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        disableFields();

    }

    public void backToLogin(ActionEvent actionEvent) throws IOException {
        returnToPrevious();
    }
}
