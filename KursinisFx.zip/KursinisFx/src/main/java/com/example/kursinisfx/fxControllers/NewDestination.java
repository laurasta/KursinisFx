package com.example.kursinisfx.fxControllers;

import com.example.kursinisfx.HelloApplication;
import com.example.kursinisfx.hibernate.DestinationHib;
import com.example.kursinisfx.hibernate.UserHib;
import com.example.kursinisfx.model.Destination;
import com.example.kursinisfx.model.Manager;
import com.example.kursinisfx.model.User;
import com.example.kursinisfx.utils.FxUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import java.io.IOException;

public class NewDestination {
    @FXML
    public MenuItem cancelDestCreate;
    @FXML
    public TextField titleField;
    @FXML
    public TextField startAddressField;
    @FXML
    public TextField endAddressField;
    @FXML
    public Button createDestinationF;

    private EntityManagerFactory entityManagerFactory;
    private User user;
    private UserHib userHib;
    private DestinationHib destinationHib;
    private User selectedUser;

    public void setData(EntityManagerFactory entityManagerFactory, User user) {
        this.entityManagerFactory = entityManagerFactory;
        this.userHib = new UserHib(entityManagerFactory);
        this.destinationHib = new DestinationHib(entityManagerFactory);
        this.user = user;
    }
    public void returnToPrevious() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("all-destinations-window.fxml"));
        Parent root = fxmlLoader.load();

        AllDestinationsWindow allDestinationsWindow = fxmlLoader.getController();
        allDestinationsWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    public void CreateDestination() throws IOException {
        Manager manager = userHib.getManagerById(user.getId());
        Destination destination = new Destination(titleField.getText(),startAddressField.getText(), endAddressField.getText(), manager);
        destinationHib.createDestination(destination);

        FxUtils.generateAlert(Alert.AlertType.INFORMATION, "Destination report", "Destination created successfully!");
    returnToPrevious();
    }

}
