package com.example.kursinisfx.fxControllers;

import com.example.kursinisfx.HelloApplication;
import com.example.kursinisfx.hibernate.CommentHib;
import com.example.kursinisfx.hibernate.DestinationHib;
import com.example.kursinisfx.hibernate.ForumHib;
import com.example.kursinisfx.hibernate.UserHib;
import com.example.kursinisfx.model.Cargo;
import com.example.kursinisfx.model.Comment;
import com.example.kursinisfx.model.Forum;
import com.example.kursinisfx.model.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import java.io.IOException;
import java.util.List;

public class ForumWindow {
    @FXML
    public MenuItem logOutBtn;
    @FXML
    public MenuItem destinationsBtn;
    @FXML
    public MenuItem usersBtn;
    @FXML
    public ListView forumList;
    @FXML
    public TreeView commentTree;
    @FXML
    public MenuItem ReplyItem;
    @FXML
    public MenuItem deleteItem;
    @FXML
    public MenuItem forumBtn;
    public Button createForumBtn;
    public Button deleteForumBtn;
    public Button createCommentBtn;

    private EntityManagerFactory entityManagerFactory;
    private UserHib userHib;
    private CommentHib commentHib;
    private DestinationHib destinationHib;
    private ForumHib forumHib;
    private User user;

    public void setData(EntityManagerFactory entityManagerFactory, User user) {
        this.entityManagerFactory = entityManagerFactory;
        this.userHib = new UserHib(entityManagerFactory);
        this.forumHib = new ForumHib(entityManagerFactory);
        this.commentHib = new CommentHib(entityManagerFactory);
        this.user = user;
        fillTables();
    }
    private void fillTables(){
        forumList.getItems().clear();
        List<Forum> forumsL = forumHib.getAllForums();
        for (Forum c : forumsL){
            forumList.getItems().add(c.getId() + ": " + c.getTitle());
        }

    }
    public void allUsers() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("all-users-window.fxml"));
        Parent root = fxmlLoader.load();

        AllUsersWindow allUsersWindow = fxmlLoader.getController();
        allUsersWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) forumList.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void allDestinations() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("all-destinations-window.fxml"));
        Parent root = fxmlLoader.load();

        AllDestinationsWindow allDestinationsWindow = fxmlLoader.getController();
        allDestinationsWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) forumList.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void logout() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("login-page.fxml"));

        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) forumList.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    public void goToForum() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("forum-window.fxml"));
        Parent root = fxmlLoader.load();

        ForumWindow forumWindow = fxmlLoader.getController();
        forumWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) forumList.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void loadComments() {
//        List<Comment> comments = forumHib.getForumById(Integer.parseInt(forumList.getSelectionModel().getSelectedItem().toString().split(":")[0])).getComments();
//        selectedDestination = destinationHib.getDestinationById(Integer.parseInt(allDestinationsL.getSelectionModel().getSelectedItem().toString().split(":")[0]));
        Forum selectedforum = forumHib.getForumById(Integer.parseInt(forumList.getSelectionModel().getSelectedItem().toString().split(":")[0]));
        commentTree.setRoot(new TreeItem<>(new Comment()));
        commentTree.setShowRoot(false);
        commentTree.getRoot().setExpanded(true);
        selectedforum.getComments().forEach(comment -> addTreeItem(comment, commentTree.getRoot()));
    }

    private void addTreeItem(Comment comment, TreeItem parent) {
        TreeItem<Comment> treeItem = new TreeItem<>(comment);
        parent.getChildren().add(treeItem);
        comment.getReplies().forEach(r -> addTreeItem(r, treeItem));
    }

    public void createComment() {
        commentHib.createComment(new Comment("Title", "Text"));
    }

    public void replyComment(ActionEvent actionEvent) {
    }

    public void deleteComment(ActionEvent actionEvent) {
    }

    public void createForum(ActionEvent actionEvent) {
    }

    public void deleteForum(ActionEvent actionEvent) {
    }
}
