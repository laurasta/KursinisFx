package com.example.kursinisfx.fxControllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;

public class NewVehicleWindow {
    @FXML
    public MenuItem cancelVehicleCreate;
    @FXML
    public TextField modelField;
    @FXML
    public TextField licenseNumberField;
    @FXML
    public Button createVehicleF;

    public void returnToPrevious() {
    }

    public void CreateVehicle() {
    }
}
