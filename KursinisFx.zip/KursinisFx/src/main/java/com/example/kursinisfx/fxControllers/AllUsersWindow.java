package com.example.kursinisfx.fxControllers;

import com.example.kursinisfx.HelloApplication;
import com.example.kursinisfx.hibernate.CommentHib;
import com.example.kursinisfx.hibernate.DestinationHib;
import com.example.kursinisfx.hibernate.ForumHib;
import com.example.kursinisfx.hibernate.UserHib;
import com.example.kursinisfx.model.User;
import com.example.kursinisfx.model.UserType;
import com.example.kursinisfx.utils.FxUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AllUsersWindow implements Initializable {
    @FXML
    public MenuItem backButton;
    @FXML
    public ListView allUsersL;
    @FXML
    public Button deleteBtn;
    @FXML
    public Button updateBtn;
    @FXML
    public Button createBtn;
    @FXML
    public MenuItem logOutBtn;
    @FXML
    public MenuItem destinationsBtn;
    @FXML
    public MenuItem usersBtn;
    @FXML
    public MenuItem forumBtn;
    private EntityManagerFactory entityManagerFactory;
    private UserHib userHib;
    private CommentHib commentHib;
    private DestinationHib destinationHib;
    private ForumHib forumHib;
    private User user;
    private User selectedUser;

    public void setData(EntityManagerFactory entityManagerFactory, User user) {
        this.entityManagerFactory = entityManagerFactory;
        this.userHib = new UserHib(entityManagerFactory);
        this.user = user;
        fillTables();
    }

    private void fillTables() {
        allUsersL.getItems().clear();
        List<User> usersFromDatabase = userHib.getAllUsers();
        for (User u : usersFromDatabase) {
            allUsersL.getItems().add(u.getId() + ":" + u.getLogin() + " " + u.getUserType());
        }
    }

    public void returnToMain(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("main-window.fxml"));
        Parent root = fxmlLoader.load();

        MainWindow mainWindow = fxmlLoader.getController();
        mainWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allUsersL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void deleteUser(ActionEvent actionEvent) {
        selectedUser = userHib.getUserById(Integer.parseInt(allUsersL.getSelectionModel().getSelectedItem().toString().split(":")[0]));
        if (selectedUser.getUserType() != UserType.ADMIN) userHib.removeUser(selectedUser);

        //userHib.removeUser(userHib.getUserById(selectedUser.getId()));
        else FxUtils.generateAlert(Alert.AlertType.INFORMATION, "User delete report", "ADMIN user cannot be deleted!");
        fillTables();
    }

    public void updateUser(ActionEvent actionEvent) throws IOException {
        selectedUser = userHib.getUserById(Integer.parseInt(allUsersL.getSelectionModel().getSelectedItem().toString().split(":")[0]));
        if (selectedUser.getUserType() != UserType.ADMIN) {

            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("registration-page.fxml"));
            Parent root = fxmlLoader.load();

            RegistrationPage registrationPage = fxmlLoader.getController();
            registrationPage.setData(entityManagerFactory, user, selectedUser);

            Scene scene = new Scene(root);
            Stage stage = (Stage) allUsersL.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } else {
            FxUtils.generateAlert(Alert.AlertType.INFORMATION, "User update report", "ADMIN user cannot be modified!");
        }
    }

    public void createUser(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("registration-page.fxml"));
        Parent root = fxmlLoader.load();

        RegistrationPage registrationPage = fxmlLoader.getController();
        registrationPage.setData(entityManagerFactory);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allUsersL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void allUsers() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("all-users-window.fxml"));
        Parent root = fxmlLoader.load();

        AllUsersWindow allUsersWindow = fxmlLoader.getController();
        allUsersWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allUsersL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void allDestinations() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("all-destinations-window.fxml"));
        Parent root = fxmlLoader.load();

        AllDestinationsWindow allDestinationsWindow = fxmlLoader.getController();
        allDestinationsWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allUsersL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void logout() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("login-page.fxml"));

        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) allUsersL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void goToForum() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("forum-window.fxml"));
        Parent root = fxmlLoader.load();

        ForumWindow forumWindow = fxmlLoader.getController();
        forumWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allUsersL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
