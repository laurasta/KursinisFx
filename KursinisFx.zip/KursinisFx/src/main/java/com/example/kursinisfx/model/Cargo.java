package com.example.kursinisfx.model;

import lombok.*;
import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Cargo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String content;
    private String type;
    private String weight;

    @ManyToOne
    private Destination cargoDestination;
    @ManyToOne
    private Checkpoint cargoCheckpoint;

    public Cargo(String content, String type, String weight, Checkpoint cargoCheckpoint, Destination cargoDestination) {
        this.content = content;
        this.type = type;
        this.weight = weight;
        this.cargoCheckpoint = cargoCheckpoint;
        this.cargoDestination = cargoDestination;
    }
}