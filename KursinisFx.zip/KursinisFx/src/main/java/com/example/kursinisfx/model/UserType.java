package com.example.kursinisfx.model;

public enum UserType {
    TRUCKER,MANAGER,ADMIN
}
