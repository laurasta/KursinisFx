package com.example.kursinisfx.fxControllers;

import com.example.kursinisfx.HelloApplication;
import com.example.kursinisfx.hibernate.CommentHib;
import com.example.kursinisfx.hibernate.DestinationHib;
import com.example.kursinisfx.hibernate.ForumHib;
import com.example.kursinisfx.hibernate.UserHib;
import com.example.kursinisfx.model.Cargo;
import com.example.kursinisfx.model.Checkpoint;
import com.example.kursinisfx.model.Destination;
import com.example.kursinisfx.model.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AllDestinationsWindow implements Initializable {
    @FXML
    public MenuItem backButton;
    @FXML
    public ListView allDestinationsL;
    @FXML
    public Button deleteDBtn;
    @FXML
    public Button updateDBtn;
    @FXML
    public Button createDBtn;
    @FXML
    public MenuItem logOutBtn;
    @FXML
    public MenuItem destinationsBtn;
    @FXML
    public MenuItem usersBtn;
    @FXML
    public MenuItem forumBtn;
    @FXML
    public ListView checkpointsL;
    @FXML
    public ListView cargosL;
    @FXML
    public Button addCpBtn;
    @FXML
    public Button deleteCpBtn;
    @FXML
    public Button addCargoBtn;
    @FXML
    public Button deleteCargoBtn;

    private EntityManagerFactory entityManagerFactory;
    private UserHib userHib;
    private CommentHib commentHib;
    private DestinationHib destinationHib;
    private ForumHib forumHib;
    private User user;
    private User selectedUser;
    private Destination selectedDestination;
    private Checkpoint selectedCheckpoint;

    public void setData(EntityManagerFactory entityManagerFactory, User user) {
        this.entityManagerFactory = entityManagerFactory;
        this.userHib = new UserHib(entityManagerFactory);
        this.destinationHib = new DestinationHib(entityManagerFactory);
        this.user = user;
        fillTables();
    }

    private void fillTables(){
        allDestinationsL.getItems().clear();
        checkpointsL.getItems().clear();
        cargosL.getItems().clear();
        List<Destination> myDestList = destinationHib.getAllDestinations();
        List<Checkpoint> myCheckList = destinationHib.getAllCheckpoints();
        List<Cargo> myCargoList = destinationHib.getAllCargo();
        for(Destination d : myDestList){
            allDestinationsL.getItems().add(d.getId() + ":" + d.getTitle() + ";  responsible - " + d.getResponsibleManager().getName());
        }
        for (Checkpoint c : myCheckList){
            checkpointsL.getItems().add(c.getId() + ":" + c.getTitle() + " ; " + c.getCheckpointAddress());
        }
        for (Cargo c : myCargoList){
            cargosL.getItems().add(c.getWeight() + " ; " + c.getContent());
        }
    }
//    public void returnToMain(ActionEvent actionEvent) throws IOException {
//        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("main-window.fxml"));
//        Parent root = fxmlLoader.load();
//
//        MainWindow mainWindow = fxmlLoader.getController();
//        mainWindow.setData(entityManagerFactory, user);
//
//        Scene scene = new Scene(root);
//        Stage stage = (Stage) allDestinationsL.getScene().getWindow();
//        stage.setScene(scene);
//        stage.show();
//    }

    public void deleteDestination() {
    }

    public void updateDestination() {
    }

    public void createDestination() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("new-destination-window.fxml"));
        Parent root = fxmlLoader.load();

        NewDestination newDestination = fxmlLoader.getController();
        newDestination.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allDestinationsL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void allUsers() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("all-users-window.fxml"));
        Parent root = fxmlLoader.load();

        AllUsersWindow allUsersWindow = fxmlLoader.getController();
        allUsersWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allDestinationsL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void allDestinations() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("all-destinations-window.fxml"));
        Parent root = fxmlLoader.load();

        AllDestinationsWindow allDestinationsWindow = fxmlLoader.getController();
        allDestinationsWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allDestinationsL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void logout() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("login-page.fxml"));

        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) allDestinationsL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    public void goToForum() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("forum-window.fxml"));
        Parent root = fxmlLoader.load();

        ForumWindow forumWindow = fxmlLoader.getController();
        forumWindow.setData(entityManagerFactory, user);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allDestinationsL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void addCheckpoint() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("new-checkpoint-window.fxml"));
        Parent root = fxmlLoader.load();

        selectedDestination = destinationHib.getDestinationById(Integer.parseInt(allDestinationsL.getSelectionModel().getSelectedItem().toString().split(":")[0]));
        NewCheckpointWindow newCheckpointWindow = fxmlLoader.getController();
        newCheckpointWindow.setData(entityManagerFactory, user, selectedDestination);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allDestinationsL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void deleteCheckpoint(ActionEvent actionEvent) {
    }

    public void addCargo() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("new-cargo-window.fxml"));
        Parent root = fxmlLoader.load();

        selectedCheckpoint = destinationHib.getCheckpointById(Integer.parseInt(checkpointsL.getSelectionModel().getSelectedItem().toString().split(":")[0]));
        NewCargoWindow newCargoWindow = fxmlLoader.getController();
        newCargoWindow.setData(entityManagerFactory, user, selectedCheckpoint, selectedDestination);

        Scene scene = new Scene(root);
        Stage stage = (Stage) allDestinationsL.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void deleteCargo(ActionEvent actionEvent) {
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
