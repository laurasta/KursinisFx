package com.example.kursinisfx.model;

public enum DriverLicenses {
    AM,
    A1,
    A2,
    A,
    B1,
    B,
    C1,
    C,
    D1,
    D,
    BE,
    C1E,
    CE,
    D1E,
    DE,
    T;
}
