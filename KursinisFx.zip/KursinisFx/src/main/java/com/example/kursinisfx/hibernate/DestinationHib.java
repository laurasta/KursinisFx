package com.example.kursinisfx.hibernate;

import com.example.kursinisfx.model.Cargo;
import com.example.kursinisfx.model.Checkpoint;
import com.example.kursinisfx.model.Destination;
import com.example.kursinisfx.model.User;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

public class DestinationHib {
    EntityManager entityManager = null;
    EntityManagerFactory entityManagerFactory = null;

    public DestinationHib(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
    }

    public void createDestination(Destination destination) {
        entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(destination);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }
    public void createCheckpoint(Checkpoint checkpoint) {
        entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(checkpoint);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }
    public void createCargo(Cargo cargo) {
        entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(cargo);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) entityManager.close();
        }
    }

    //READ
    public Checkpoint getCheckpointById(int id) {
        entityManager = entityManagerFactory.createEntityManager();
        Checkpoint checkpoint = null;
        try {
            entityManager.getTransaction().begin();
            checkpoint = entityManager.find(Checkpoint.class, id);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            System.out.println("No such checkpoint by given Id");
        }
        return checkpoint;
    }
    public Destination getDestinationById(int id) {
        entityManager = entityManagerFactory.createEntityManager();
        Destination destination = null;
        try {
            entityManager.getTransaction().begin();
            destination = entityManager.find(Destination.class, id);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            System.out.println("No such destination by given Id");
        }
        return destination;
    }

//    public List<Destination> getDestinationByUserId(int id) {
//        entityManager = entityManagerFactory.createEntityManager();
//        Destination destination = null;
//        CriteriaBuilder cb = entityManagerFactory.getCriteriaBuilder();
//        CriteriaQuery<Destination> query = cb.createQuery(Destination.class);
//
//        Root<Destination> root = query.from(Destination.class);
//
//        CriteriaBuilder.In<Integer> inClause = cb.in(root.get("id"));
//        //Trucker trucker = entityManager.find(Trucker.class, id);
//        User user = entityManager.getReference(User.class, id);
//        for (Destination d : user.getMyDestinations()) {
//            inClause.value(d.getId());
//        }
//        query.select(root).where(inClause);
//        Query q;
//        try {
//            q = entityManager.createQuery(query);
//            return q.getResultList();
//        } catch (NoResultException e) {
//            return null;
//        }
//    }

    public List<Cargo> getAllCargo(){
        entityManager = entityManagerFactory.createEntityManager();
        try {
            CriteriaQuery<Object> query = entityManager.getCriteriaBuilder().createQuery();
            query.select(query.from(Cargo.class));
            Query q = entityManager.createQuery(query);
            return q.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) {
                entityManager.close();
            }
        }
        return new ArrayList<>();
    }
    public List<Checkpoint> getAllCheckpoints(){
        entityManager = entityManagerFactory.createEntityManager();
        try {
            CriteriaQuery<Object> query = entityManager.getCriteriaBuilder().createQuery();
            query.select(query.from(Checkpoint.class));
            Query q = entityManager.createQuery(query);
            return q.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) {
                entityManager.close();
            }
        }
        return new ArrayList<>();
    }


    public List<Destination> getAllDestinations() {
        entityManager = entityManagerFactory.createEntityManager();
        try {
            CriteriaQuery<Object> query = entityManager.getCriteriaBuilder().createQuery();
            query.select(query.from(Destination.class));
            Query q = entityManager.createQuery(query);
            return q.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null) {
                entityManager.close();
            }
        }
        return new ArrayList<>();
    }
}
