package com.example.kursinisfx.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Forum implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String title;
    private String description;
    @OneToMany(mappedBy = "parentForum", cascade = CascadeType.ALL)
    private List<Comment> comments;

    public Forum(String title, String description) {
        this.title = title;
        this.description = description;
        this.comments = new ArrayList<>();
    }
}